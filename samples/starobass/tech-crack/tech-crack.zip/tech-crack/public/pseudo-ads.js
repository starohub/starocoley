var root = document.getElementById('hot-wrapper');
root.style.display = 'none';
root = document.getElementById('home-ad');
root.style.display = 'none';